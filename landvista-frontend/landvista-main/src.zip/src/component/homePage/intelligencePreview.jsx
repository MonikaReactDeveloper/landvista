import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

const signal = {
  type: "Infrastructure Signal",
  zone: "Zone L",
  indicator: "Connectivity expansion",
  confidence: "High",
  risk: "Medium",
  source: "Multi-source validated",
  narrative:
    "Improved infrastructure connectivity indicates enhanced development viability over the medium term.",
};

const fields = [
  { label: "Signal Type", value: signal.type },
  { label: "Zone", value: signal.zone },
  { label: "Indicator", value: signal.indicator },
  { label: "Confidence", value: signal.confidence },
  { label: "Risk Level", value: signal.risk },
  { label: "Source", value: signal.source },
];

const confidenceColor = {
  High: "text-emerald-600 bg-emerald-50",
  Medium: "text-amber-600 bg-amberald-50",
  Low: "text-red-600 bg-red-50",
};

const riskColor = {
  High: "text-red-600 bg-red-50",
  Medium: "text-amber-600 bg-amber-50",
  Low: "text-emerald-600 bg-emerald-50",
};

export default function IntelligencePreview() {
  const [revealed, setRevealed] = useState(false);

  return (
    <section className="w-full bg-white py-16 md:py-24 border-t border-gray-100">
      <div className="max-w-6xl mx-auto px-6 md:px-10">

        {/* HEADER */}
        <div className="mb-12 md:mb-16">
          <p className="text-[12px] uppercase tracking-[0.14em] text-landvista-muted mb-3">
            Intelligence Preview
          </p>
          <h2 className="text-[28px] md:text-[36px] font-semibold text-landvista-charcoal max-w-2xl leading-snug">
            Structured output — not speculation
          </h2>
        </div>

        {/* SIGNAL CARD */}
        <div className="border border-gray-200 rounded-lg overflow-hidden">

          {/* CARD HEADER */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-gray-100 border-b border-gray-200">
            {fields.map((f) => (
              <div key={f.label} className="p-5">
                <p className="text-[10px] uppercase tracking-[0.14em] text-landvista-muted mb-1.5">
                  {f.label}
                </p>
                <p
                  className={`text-[13px] font-semibold inline-block px-2 py-0.5 rounded ${
                    f.label === "Confidence"
                      ? confidenceColor[f.value] || "text-landvista-charcoal"
                      : f.label === "Risk Level"
                      ? riskColor[f.value] || "text-landvista-charcoal"
                      : "text-landvista-charcoal"
                  }`}
                >
                  {f.value}
                </p>
              </div>
            ))}
          </div>

          {/* NARRATIVE */}
          <div className="p-8 bg-gray-50 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <p className="text-[11px] uppercase tracking-[0.14em] text-landvista-muted mb-2">
                Insight Narrative
              </p>
              <p
                className={`text-[15px] md:text-[16px] text-landvista-grey leading-relaxed max-w-2xl transition-all duration-500 ${
                  revealed ? "opacity-100 blur-none" : "opacity-40 blur-sm select-none"
                }`}
              >
                {signal.narrative}
              </p>
            </div>
            <button
              onClick={() => setRevealed((r) => !r)}
              className="shrink-0 flex items-center gap-2 border border-landvista-blue text-landvista-blue px-5 py-2.5 text-[13px] font-medium hover:bg-landvista-blue hover:text-white transition"
            >
              {revealed ? "Hide narrative" : "Reveal intelligence"}
              <ChevronDown
                size={14}
                className={`transition-transform ${revealed ? "rotate-180" : ""}`}
              />
            </button>
          </div>
        </div>

        <p className="mt-6 text-[12px] text-landvista-muted italic">
          * Sample preview. Full intelligence access requires qualification and NDA acceptance.
        </p>

      </div>
    </section>
  );
}
