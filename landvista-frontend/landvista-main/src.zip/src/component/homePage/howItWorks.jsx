import React, { useState } from "react";

const steps = [
  {
    id: "01",
    label: "Discover",
    detail: "Identify TerraSignal through institutional channels or direct referral.",
  },
  {
    id: "02",
    label: "Qualification",
    detail: "Submit your profile for institutional review. Applications are assessed for fit.",
  },
  {
    id: "03",
    label: "NDA",
    detail: "Execute a non-disclosure agreement before accessing any intelligence layer.",
  },
  {
    id: "04",
    label: "Access",
    detail: "Receive tiered platform access aligned to your qualification level.",
  },
  {
    id: "05",
    label: "Intelligence Review",
    detail: "Explore structured signals, zone data, and sector-level insights.",
  },
  {
    id: "06",
    label: "Decision Support",
    detail: "Leverage the intelligence framework to support disciplined land decisions.",
  },
];

export default function HowItWorks() {
  const [active, setActive] = useState(0);

  return (
    <section className="w-full bg-landvista-bg py-16 md:py-24 border-t border-gray-100">
      <div className="max-w-6xl mx-auto px-6 md:px-10">

        {/* HEADER */}
        <div className="mb-12 md:mb-16">
          <p className="text-[12px] uppercase tracking-[0.14em] text-landvista-muted mb-3">
            How It Works
          </p>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <h2 className="text-[28px] md:text-[36px] font-semibold text-landvista-charcoal">
              A governed qualification process
            </h2>
            <p className="text-[13px] text-landvista-muted max-w-xs">
              Each stage is governed and validated
            </p>
          </div>
        </div>

        {/* STEPS — desktop horizontal stepper */}
        <div className="hidden md:flex items-start gap-0 mb-10">
          {steps.map((step, i) => (
            <button
              key={step.id}
              onClick={() => setActive(i)}
              className={`flex-1 text-left border-t-2 pt-6 pr-6 transition-all duration-200 ${
                active === i
                  ? "border-landvista-blue"
                  : "border-gray-200 hover:border-gray-400"
              }`}
            >
              <p
                className={`text-[11px] uppercase tracking-[0.16em] mb-2 ${
                  active === i ? "text-landvista-blue" : "text-landvista-muted"
                }`}
              >
                {step.id}
              </p>
              <p
                className={`text-[14px] font-semibold ${
                  active === i ? "text-landvista-charcoal" : "text-landvista-grey"
                }`}
              >
                {step.label}
              </p>
            </button>
          ))}
        </div>

        {/* ACTIVE DETAIL — desktop */}
        <div className="hidden md:block bg-white border border-gray-100 p-8 rounded-lg">
          <p className="text-[12px] uppercase tracking-[0.14em] text-landvista-muted mb-3">
            Stage {steps[active].id} — {steps[active].label}
          </p>
          <p className="text-[16px] text-landvista-grey leading-relaxed max-w-2xl">
            {steps[active].detail}
          </p>
        </div>

        {/* STEPS — mobile accordion */}
        <div className="md:hidden space-y-3">
          {steps.map((step, i) => (
            <div
              key={step.id}
              className="border border-gray-200 rounded-lg overflow-hidden"
            >
              <button
                onClick={() => setActive(active === i ? -1 : i)}
                className="w-full flex items-center justify-between p-5 text-left"
              >
                <div className="flex items-center gap-4">
                  <span className="text-[11px] uppercase tracking-widest text-landvista-muted w-6">
                    {step.id}
                  </span>
                  <span className="text-[15px] font-semibold text-landvista-charcoal">
                    {step.label}
                  </span>
                </div>
                <span
                  className={`text-landvista-muted transition-transform ${
                    active === i ? "rotate-45" : ""
                  }`}
                >
                  +
                </span>
              </button>
              {active === i && (
                <div className="px-5 pb-5 text-[14px] text-landvista-grey leading-relaxed border-t border-gray-100 pt-4">
                  {step.detail}
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
