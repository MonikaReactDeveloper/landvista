import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import api from '../../utils/api';

// Static fallback images cycled across zones
const fallbackImages = [
  'https://images.unsplash.com/photo-1521737604893-d14cc237f11d',
  'https://images.unsplash.com/photo-1509099836639-18ba1795216d',
  'https://images.unsplash.com/photo-1556761175-4b46a572b786',
  'https://images.unsplash.com/photo-1486325212027-8081e485255e',
  'https://images.unsplash.com/photo-1507679799987-c73779587ccf',
];

export default function OurCommitment() {
  const navigate = useNavigate();
  const [zones, setZones] = useState([]);

  useEffect(() => {
    const fetchZones = async () => {
      try {
        const response = await api.get('/policy/zones');
        const data = response.data.data || response.data;
        setZones(Array.isArray(data) ? data.slice(0, 3) : []);
      } catch (error) {
        console.error('Failed to fetch zones', error);
      }
    };
    fetchZones();
  }, []);

  return (
    <section className="w-full bg-landvista-bg py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6 md:px-10">

        {/* HEADER */}
        <div className="flex items-end justify-between mb-12 md:mb-16">
          <h2 className="text-[28px] md:text-[36px] font-semibold text-landvista-charcoal">
            Policy &amp; Zones
          </h2>
          <button
            onClick={() => navigate('/policy-zones')}
            className="group flex items-center gap-2 text-[13px] font-medium text-landvista-blue border-b border-landvista-blue pb-0.5 hover:opacity-70 transition whitespace-nowrap"
          >
            View all
            <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* GRID */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {zones.map((zone, i) => (
            <div
              key={zone.id || zone._id || i}
              onClick={() => zone.status !== 'locked' && navigate(`/policy-zones/${zone.slug}`)}
              className={`relative group h-[320px] md:h-[380px] overflow-hidden ${zone.status === 'locked' ? 'cursor-not-allowed opacity-70' : 'cursor-pointer'}`}
            >
              {/* IMAGE */}
              <img
                src={zone.image || fallbackImages[i % fallbackImages.length]}
                alt={zone.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />

              {/* OVERLAY */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent transition duration-300" />

              {/* CONTENT */}
              <div className="absolute inset-0 flex flex-col justify-between p-6 text-white">

                {/* TOP TEXT */}
                <div>
                  {zone.status === 'locked' && (
                    <span className="inline-block text-[10px] uppercase tracking-widest bg-white/20 px-2 py-0.5 rounded mb-2">
                      Restricted
                    </span>
                  )}
                  <p className="text-[12px] uppercase tracking-[0.12em] text-gray-200 mb-2">
                    Policy Zone
                  </p>
                  <h3 className="text-[22px] md:text-[24px] font-semibold">
                    {zone.name}
                  </h3>
                </div>

                {/* HOVER DESCRIPTION */}
                <div className="opacity-0 translate-y-6 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                  <p className="text-[14px] text-gray-200 leading-relaxed mb-3">
                    {zone.description}
                  </p>
                  {zone.status !== 'locked' && (
                    <span className="inline-flex items-center gap-1.5 text-[12px] font-medium text-white/80 border-b border-white/40 pb-0.5">
                      Explore Zone <ArrowRight size={12} />
                    </span>
                  )}
                </div>

              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}